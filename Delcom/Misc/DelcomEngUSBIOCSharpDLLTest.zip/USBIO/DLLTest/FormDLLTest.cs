//Delcom USB-IO DLL Test Application
//
//This software is as is with no warranty of function. Use at your own risk.
//
//This provides a quick test of the Delcom Engineering�s USB-IO chip DLL and 
//may serve as a sample application. If you find an error please forward any
//corrections so others may benefit.
//
//The required DelcomDLL.dll file, documentation and the USB-IO chips can be 
//found at the Delcom Engineering web site.
//http://www.delcom-eng.com/
//
//If you find this code useful, provide a link back to uC Hobby and let me 
//know what you are doing.
//
//http://www.uchobby.com
//David Fowler - dfowler@uchobby.com
//
using System;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;

namespace DLLTest
{
	/// <summary>
	/// Summary description for FormDLLTest.
	/// </summary>
	public class FormDLLTest : Form
	{
    private TextBox textBoxMessage;
    private Button buttonTest;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private Container components = null;

		public FormDLLTest()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.textBoxMessage = new System.Windows.Forms.TextBox();
      this.buttonTest = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // textBoxMessage
      // 
      this.textBoxMessage.Location = new System.Drawing.Point(0, 24);
      this.textBoxMessage.Multiline = true;
      this.textBoxMessage.Name = "textBoxMessage";
      this.textBoxMessage.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.textBoxMessage.Size = new System.Drawing.Size(288, 136);
      this.textBoxMessage.TabIndex = 0;
      this.textBoxMessage.Text = "";
      this.textBoxMessage.WordWrap = false;
      // 
      // buttonTest
      // 
      this.buttonTest.Location = new System.Drawing.Point(208, 240);
      this.buttonTest.Name = "buttonTest";
      this.buttonTest.TabIndex = 1;
      this.buttonTest.Text = "Test";
      this.buttonTest.Click += new System.EventHandler(this.buttonTest_Click);
      // 
      // FormDLLTest
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.buttonTest);
      this.Controls.Add(this.textBoxMessage);
      this.Name = "FormDLLTest";
      this.Text = "FormDLLTest";
      this.ResumeLayout(false);

    }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new FormDLLTest());
		}

    private void buttonTest_Click(object sender, EventArgs e) {
      StringBuilder stringResult=new StringBuilder(DelcomUSBIOAdaptor.MAXDEVICENAMELEN);
      int intResult;
      int deviceHandle;
      DelcomUSBIOAdaptor.PacketStructure commandPacket=new DelcomUSBIOAdaptor.PacketStructure();
      DelcomUSBIOAdaptor.PacketStructure responsePacket=new DelcomUSBIOAdaptor.PacketStructure();
      
      MessageWindowWriteLine("GetVersion:");
      double version = DelcomUSBIOAdaptor.GetVersion();
      MessageWindowWriteLine(String.Format("Version={0}", version));

      MessageWindowWriteLine("DelcomGetDLLDate:");
      intResult=DelcomUSBIOAdaptor.DelcomGetDLLDate(stringResult);
      MessageWindowWriteLine(String.Format("intResult={0}  stringResult={1}", intResult, stringResult));
      
      MessageWindowWriteLine("DelcomGetDeviceCount:");
      intResult=DelcomUSBIOAdaptor.DelcomGetDeviceCount(DelcomUSBIOAdaptor.USBIODS);
      MessageWindowWriteLine(String.Format("intResult={0}", intResult));
      
      MessageWindowWriteLine("DelcomGetNthDevice:");
      intResult=DelcomUSBIOAdaptor.DelcomGetNthDevice(DelcomUSBIOAdaptor.USBIODS,0,stringResult);
      MessageWindowWriteLine(String.Format("intResult={0}  stringResult={1}", intResult, stringResult));
      
      MessageWindowWriteLine("DelcomOpenDevice:");
      intResult=DelcomUSBIOAdaptor.DelcomOpenDevice(stringResult,0);
      deviceHandle = intResult;
      MessageWindowWriteLine(String.Format("intResult={0}", intResult));
    
      MessageWindowWriteLine("DelcomReadDeviceVersion:");
      intResult=DelcomUSBIOAdaptor.DelcomReadDeviceVersion(deviceHandle);
      MessageWindowWriteLine(String.Format("intResult={0}", intResult));

      MessageWindowWriteLine("DelcomReadDeviceSerialNum:");
      intResult=DelcomUSBIOAdaptor.DelcomReadDeviceSerialNum(null,deviceHandle);
      MessageWindowWriteLine(String.Format("intResult={0}", intResult));

      MessageWindowWriteLine("DelcomSendPacket:");
      commandPacket.recipient = 8;
      commandPacket.deviceModel = 18;
      commandPacket.majorCmd = 10;
      commandPacket.minorCmd = 2;
      commandPacket.dataLSB = 0x7F;
      intResult=DelcomUSBIOAdaptor.DelcomSendPacket(deviceHandle,ref commandPacket,ref responsePacket);
      MessageWindowWriteLine(String.Format("intResult={0}", intResult));
      
      MessageWindowWriteLine("DelcomSendPacket 20000X:");
      for(int cycle=0;cycle<5000;cycle++) {
        commandPacket.dataLSB = 0x7F;
        intResult=DelcomUSBIOAdaptor.DelcomSendPacket(deviceHandle,ref commandPacket,ref responsePacket);
        commandPacket.dataLSB = 0xFF;
        intResult=DelcomUSBIOAdaptor.DelcomSendPacket(deviceHandle,ref commandPacket,ref responsePacket);
      }
      MessageWindowWriteLine("done!");
      
      MessageWindowWriteLine("DelcomCloseDevice:");
      intResult=DelcomUSBIOAdaptor.DelcomCloseDevice(intResult);
      MessageWindowWriteLine(String.Format("intResult={0}", intResult));

    }
	  
	  private void MessageWindowWriteLine(string message) {
      textBoxMessage.Text += message+"\r\n";
	    Application.DoEvents();
	  }
	}
}
