//Delcom USB-IO DLL Adaptor
//
//This software is as is with no warranty of function. Use at your own risk.
//
//This module provides an adaptor to Delcom Engineering's USB-IO chip DLL. I created 
//this code using information in the DLL documentation and in a VB.NET sample available 
//at their site. I have not tested all the functions. If you find an error please 
//forward any corrections so others may benefit.
//
//http://www.delcom-eng.com/
//
//I don't believe this kind of code can be Copyright as there really is no original 
//content, just some typing. If you find this code useful, to keep your conscience 
//clear and to repay the work my typing may save you, just provide a link back to 
//uC Hobby and let me know what you are doing.
//
//http://www.uchobby.com
//David Fowler - dfowler@uchobby.com
//
using System.Runtime.InteropServices;
using System.Text;

namespace DLLTest {
  public class DelcomUSBIOAdaptor {
    //Delcom USB Devices
    public static byte USBIODS = 1;
    public static byte USBDELVI = 2;
    public static byte USBNDSPY = 3;

    //USBDELVI LED MODES
    public static byte LEDOFF = 0;
    public static byte LEDON = 1;
    public static byte LEDFLH = 2;

    //USBDELVI LED COlORS
    public static byte GREENLED = 0;
    public static byte REDLED = 1;
    public static byte BLUELED = 2;

    //Device Name Maximum Length
    public static int MAXDEVICENAMELEN = 512;

    //USB Packet Structures

    //USB Data IO Packact
    [StructLayout(LayoutKind.Sequential)]
      public struct PacketStructure {
      public byte recipient;
      public byte deviceModel;
      public byte majorCmd;
      public byte minorCmd;
      public byte dataLSB;
      public byte dataMSB;
      public short length;
      public byte dataExt0;
      public byte dataExt1;
      public byte dataExt2;
      public byte dataExt3;
      public byte dataExt4;
      public byte dataExt5;
      public byte dataExt6;
      public byte dataExt7;
    }
    
    //Return data struture
    [StructLayout(LayoutKind.Sequential)]
      public struct DataExtStructure {
      public byte data0;
      public byte data1;
      public byte data2;
      public byte data3;
      public byte data4;
      public byte data5;
      public byte data6;
      public byte data7;
    }

    //Delcom DLL Fucnctions - See the DelcomDLL.pdf for documentation

    //Gets the DelcomDLL verison
    [DllImport("delcomdll.dll", EntryPoint="DelcomGetDLLVersion", CallingConvention=CallingConvention.Cdecl)]
    public static extern double GetVersion();

    //Sets the verbose controll - used for debugging
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomVerboseControl(long Mode, StringBuilder caption);

    //Gets the DLL date
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomGetDLLDate(StringBuilder datestring);

    //Generic Functions

    //Gets DeviceCount
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomGetDeviceCount(int ProductType);
    
    // Gets Nth Device
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomGetNthDevice(int ProductType,int NthDevice,StringBuilder DeviceName);
    
    // Open Device
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomOpenDevice(StringBuilder DeviceName,int Mode);
    
    // Close Device
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomCloseDevice(int DeviceHandle);
    
    //Read USB Device Version
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomReadDeviceVersion(int DeviceHandle);
    
    //Read USB Device SerialNumber
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomReadDeviceSerialNum(StringBuilder DeviceName,int DeviceHandle);
    
    // Send USB Packet
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomSendPacket(int DeviceHandle,ref PacketStructure PacketOut,ref PacketStructure PacketIn);
    
    // USBDELVI  Visual Indicator Functions

    // Set LED Functions
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomLEDControl(int DeviceHandle,int Color,int Mode);

    // Set LED Freq/Duty functions
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)] 
    public static extern int DelcomLoadLedFreqDuty(int DeviceHandle,byte Color,byte Low,byte High);
    
    // Set Auto Confirm Mode
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomEnableAutoConfirm(int DeviceHandle,  int Mode);

    // Set Auto Clear Mode
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomEnableAutoClear(int DeviceHandle,  int Mode);

    // Set Buzzer Function
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomBuzzer(int DeviceHandle,byte Mode,byte Freq,byte Repeat,byte OnTime,byte OffTime);

    // Set LED Phe Delay
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomLoadInitialPheDelay(int DeviceHandle,byte Color,byte Delay);

    // Set Led Sync Functions
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomSyncLeds(int DeviceHandle);

    // Set LED PreScalar Functions
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomLoadPreScalar(int DeviceHandle,byte PreScalar);
    
    // Get Button Status
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomGetButtonStatus(int DeviceHandle);

    // Set LED Power
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomLEDPower(int DeviceHandle,int color,int Power);

    // USBIODS  USB IO Functions

    // Set Ports
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomWritePorts(int DeviceHandle,byte Port0,byte Port1);

    // Get Ports 
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomReadPorts(int DeviceHandle, ref byte Port0, ref byte Port1);

    // Set 64Bit Value
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomWrite64Bit(int DeviceHandle, ref DataExtStructure DataExt);

    // Get 64Bit Value
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomRead64Bit(int DeviceHandle, ref DataExtStructure DataExt);

    // Write I2C Functions 
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomWriteI2C(int DeviceHandle,byte CmdAdd,byte Length, ref DataExtStructure DataExt);

    // Read I2C Functions
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomReadI2C(int DeviceHandle,byte CmdAdd,byte Length, ref DataExtStructure DataExt);

    // Get I2C Slect Read 
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomSelReadI2C(int DeviceHandle,byte SetAddCmd,byte Address,byte ReadCmd,byte Length, ref DataExtStructure DataExt);

    // Setup RS232 Mode
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomRS232Ctrl(int DeviceHandle,  int Mode,int Value);

    // Write RS232 Function
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomWriteRS232(int DeviceHandle,long Length, ref DataExtStructure DataExt);

    // Read RS232 Function
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomReadRS232(int DeviceHandle, ref DataExtStructure DataExt);

    // USBNDSPY Functions
 
    // Set Numeric Mode
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomNumericMode(int DeviceHandle,byte Mode,byte Rate);

    // Set Numeric Scan Rate
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomNumericScanRate(int DeviceHandle,byte ScanRate);

    // Setup Numeric Digits
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomNumericSetup(int DeviceHandle,byte Digits);

    // Set Numeric Raw Mode
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomNumericRaw(int DeviceHandle,StringBuilder Str);

    // Set Numeric Integer Mode
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomNumericInteger(int DeviceHandle,int Number,int Be);

    // Set Numeric Hexdecimal Mode
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomNumericHexaDecimal(int DeviceHandle,int Number,int Be);

    // Set Numeric Double Mode
    [DllImport("delcomdll.dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int DelcomNumericDouble(int DeviceHandle,double Number,int Be);

  }
}