// Console.h
#include "SettingsHandler.h"

extern shared_ptr<SettingsHandler>	g_settingsHandler;
extern shared_ptr<ImageHandler>		g_imageHandler;