PASSWORD_FILE = ".password"

PASSWORD = open( PASSWORD_FILE ).read().strip()
